import chalk from 'chalk';
import { 
    formatISODate, 
    formatRelativeTime, 
    formatLongDate, 
    formatShortDate 
} from './utils/formatDate.js';

// Sample ISO dates for testing
const dates = [
    '2023-01-01T12:34:56Z',
    '2023-04-21T09:40:26Z',
    '2022-10-15T15:00:00Z',
    '2021-12-25T00:00:00Z',
    '2020-05-30T18:45:00Z'
];

// Log formatted dates to the console
dates.forEach(date => {
    console.log(chalk.blue('ISO Date: '), date);
    console.log(chalk.green('Formatted: '), formatISODate(date));
    console.log(chalk.yellow('Relative Time: '), formatRelativeTime(date));
    console.log(chalk.magenta('Long Date: '), formatLongDate(date));
    console.log(chalk.cyan('Short Date: '), formatShortDate(date));
    console.log('------------------------');
});