import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import utc from 'dayjs/plugin/utc';

dayjs.extend(relativeTime);
dayjs.extend(utc);

export function formatISODate(isoDate) {
    return dayjs(isoDate).format('MMMM D, YYYY, h:mm:ss A [UTC]');
}

export function formatRelativeTime(isoDate) {
    return dayjs(isoDate).fromNow();
}

export function formatLongDate(isoDate) {
    return dayjs(isoDate).format('dddd, MMMM D, YYYY');
}

export function formatShortDate(isoDate) {
    return dayjs(isoDate).format('MM/DD/YYYY');
}