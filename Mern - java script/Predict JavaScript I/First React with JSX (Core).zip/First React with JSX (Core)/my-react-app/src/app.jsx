import React, { useState } from 'react';
import './App.css';

function App() {
const [todos, setTodos] = useState(['Learn React', 'Learn Vite', 'Build something awesome']);
const [newTodo, setNewTodo] = useState('');

const handleAddTodo = () => {
    if (newTodo.trim() !== '') {
    setTodos([...todos, newTodo]);
    setNewTodo('');
    }
};

return (
    <div className="App">
    <h1>Hello Dojo</h1>
    <h2>My Todo List</h2>
    <ul>
        {todos.map((todo, index) => (
        <li key={index}>{todo}</li>
        ))}
    </ul>
    <input
        type="text"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
        placeholder="Add a new todo"
    />
    <button onClick={handleAddTodo}>Add Todo</button>
    </div>
);
}

export default App;