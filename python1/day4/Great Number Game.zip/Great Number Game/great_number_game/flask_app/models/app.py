from flask import Flask, render_template, request, redirect, session
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

@app.route('/')
def index():
    # Start a new game
    session['number'] = random.randint(1, 100)
    session['attempts'] = 0
    session['max_attempts'] = 5
    return render_template('index.html')

@app.route('/guess', methods=['POST'])
def guess():
    guess = int(request.form['guess'])
    session['attempts'] += 1
    number = session['number']
    attempts = session['attempts']
    
    if guess < number:
        message = "Too low!"
    elif guess > number:
        message = "Too high!"
    else:
        message = f"Correct! You guessed it in {attempts} attempts!"
        return render_template('result.html', message=message)

    if attempts >= session['max_attempts']:
        return render_template('result.html', message="You Lose! The number was " + str(number))
    
    return render_template('index.html', message=message)

@app.route('/play_again')
def play_again():
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)